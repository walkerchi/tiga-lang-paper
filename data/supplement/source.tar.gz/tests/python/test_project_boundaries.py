from __future__ import annotations

from pathlib import Path
import re
import tomllib
import unittest


ROOT = Path(__file__).resolve().parents[2]
CORE = ROOT / "python" / "tiga"


class ProjectBoundaryTest(unittest.TestCase):
    def test_core_contains_no_handwritten_triton_kernel(self):
        violations = []
        decorator = re.compile(r"^\s*@triton\.jit\b", re.MULTILINE)
        for path in CORE.rglob("*.py"):
            if decorator.search(path.read_text()):
                violations.append(str(path.relative_to(ROOT)))
        self.assertEqual(violations, [])

    def test_core_does_not_import_benchmark_oracles(self):
        violations = []
        for path in CORE.rglob("*.py"):
            text = path.read_text()
            if "benchmarks.kernels" in text or "codegen.triton" in text:
                violations.append(str(path.relative_to(ROOT)))
        self.assertEqual(violations, [])

    def test_torch_bridge_does_not_assemble_domain_mlir_source(self):
        bridge = (
            CORE / "interop" / "torch" / "compiler_bridge.py"
        ).read_text()
        self.assertNotIn("module {", bridge)
        self.assertNotIn('"gf.generated_radius"', bridge)
        self.assertNotIn("_streaming_reducer_mlir", bridge)

    def test_handwritten_oracles_are_isolated(self):
        oracle_dir = ROOT / "benchmarks" / "kernels"
        self.assertTrue((oracle_dir / "dense_streaming_reducer.py").is_file())
        self.assertTrue((oracle_dir / "sparse_triton_oracles.py").is_file())

    def test_high_level_framework_packages_are_out_of_scope(self):
        # tiga/nn is the capture adapter (tg.nn.trace): it wraps user
        # torch.nn modules into compiler-visible DAGs and owns no layers,
        # losses, or training loops.  Framework surface stays forbidden.
        forbidden = ("optim", "optimizer", "dataset", "datasets")
        violations = [
            name for name in forbidden
            if (CORE / name).exists() or (CORE / f"{name}.py").exists()
        ]
        self.assertEqual(violations, [])
        nn_dir = CORE / "nn"
        self.assertEqual(
            sorted(path.name for path in nn_dir.iterdir()
                   if path.suffix == ".py"),
            ["__init__.py"])

    def test_torch_is_an_optional_application_dependency(self):
        project = tomllib.loads((ROOT / "pyproject.toml").read_text())
        from packaging.requirements import Requirement
        dependencies = project["project"]["dependencies"]
        self.assertNotIn("torch", {Requirement(dep).name.lower() for dep in dependencies})
        self.assertIn("torch>=2.11,<2.12", project["project"]["optional-dependencies"]["torch"])

    def test_release_metadata_names_the_real_repository_and_maintainer(self):
        project = tomllib.loads((ROOT / "pyproject.toml").read_text())["project"]
        self.assertEqual(project["name"], "tiga-lang")
        identity = [{"name": "walkerchi", "email": "walker.chi.000@gmail.com"}]
        self.assertEqual(project["authors"], identity)
        self.assertEqual(project["maintainers"], identity)
        for name in ("SECURITY.md", "CITATION.cff", "docs/support.md", "docs/support.zh.md"):
            self.assertIn(identity[0]["email"], (ROOT / name).read_text())
        self.assertEqual(
            project["urls"]["Repository"],
            "https://github.com/walkerchi/TIGA-lang.git",
        )
        self.assertEqual(
            project["urls"]["Issues"],
            "https://github.com/walkerchi/TIGA-lang/issues",
        )
        getting_started = (ROOT / "docs" / "getting-started.md").read_text()
        self.assertNotIn("<repository-url>", getting_started)
        self.assertIn(
            "git clone https://github.com/walkerchi/TIGA-lang.git",
            getting_started,
        )

    def test_reducer_semantics_do_not_embed_torch_execution(self):
        core = (CORE / "reducer" / "core.py").read_text()
        self.assertNotRegex(core, r"(^|\n)import torch\b")
        self.assertNotIn("index_add_", core)
        self.assertNotIn("scatter_reduce_", core)
        self.assertTrue(
            (CORE / "interop" / "torch" / "reducer_oracle.py").is_file()
        )

    def test_native_runtime_uses_wheel_install_component(self):
        cmake = (ROOT / "lib" / "Runtime" / "CMakeLists.txt").read_text()
        self.assertRegex(
            cmake,
            r"LIBRARY DESTINATION tiga/lib\s+COMPONENT TigaWheel",
        )

    def test_native_sources_and_headers_use_tiga_names(self):
        self.assertTrue((ROOT / "include/tiga/Dialect/Domain/DomainOps.td").is_file())
        self.assertFalse((ROOT / "include" / ("graph" + "forge")).exists())
        for directory in ("include", "lib", "python/tiga", "python_bindings"):
            for path in (ROOT / directory).rglob("*"):
                if path.is_file() and (path.suffix in (".h", ".td", ".cpp", ".py")
                                       or path.name == "CMakeLists.txt"):
                    self.assertNotIn("graph" + "forge", path.read_text().lower(), str(path))
        binding = (ROOT / "python_bindings/CMakeLists.txt").read_text()
        self.assertIn("Python3_add_library(_tiga_compiler", binding)
        runtime = (ROOT / "lib/Runtime/CMakeLists.txt").read_text()
        self.assertIn("OUTPUT_NAME tiga_runtime", runtime)

    def test_tools_use_the_defined_install_rpath(self):
        root_cmake = (ROOT / "CMakeLists.txt").read_text()
        self.assertIn('set(TIGA_TOOL_RPATH "$ORIGIN/../lib")', root_cmake)
        for name in ("gf-opt", "gf-translate"):
            source = (ROOT / "tools" / name / "CMakeLists.txt").read_text()
            self.assertIn('INSTALL_RPATH "${TIGA_TOOL_RPATH}"', source)

    def test_dependency_notices_and_design_archives_have_clear_boundaries(self):
        self.assertEqual(
            {p.name for p in (ROOT / "third_party").iterdir()},
            {"README.md", "licenses"},
        )
        self.assertFalse((ROOT / ".gitmodules").exists())
        for name in ("PROJECT.md", "DESIGN_DECISION_TIMELINE.md"):
            self.assertFalse((ROOT / name).exists())
            self.assertTrue((ROOT / "docs/archive" / name).is_file())
        self.assertIn("archive/**", (ROOT / "mkdocs.yml").read_text())

    def test_major_subsystems_are_packages_not_flat_modules(self):
        subsystems = (
            "autograd",
            "compiler",
            "distributed",
            "graph",
            "kernel",
            "message_passing",
            "reducer",
            "runtime",
            "tensor",
        )
        for name in subsystems:
            self.assertTrue((CORE / name / "__init__.py").is_file(), name)
            self.assertFalse((CORE / f"{name}.py").exists(), name)


if __name__ == "__main__":
    unittest.main()
