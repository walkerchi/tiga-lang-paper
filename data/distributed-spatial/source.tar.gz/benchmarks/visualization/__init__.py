"""Visualization product-layer benchmarks."""
