# Three question-led experiments

The paper and [documentation](../docs/experiments.md) organize current evidence
around performance/memory, single-GPU capacity through 1B edges, and heterogeneous
two-GPU graph partitioning. Results include negative outcomes.

- `graph_operations/run_paper_comparison.py`: bounded 27-process matrix, four
  warmups and ten samples, stored CSR plus genuinely changing radius/kNN inputs.
  Peers include Torch sparse and PyG, with complete dynamic edge-set and output
  checks. Every process reports measured peak Torch allocation and provenance.
- `memory_hierarchy/billion_edges.py`: existing fully checked 10M/100M/1B sweep.
  `memory_hierarchy/profile_paging.py` adds a separate bounded 10M host/CUDA
  diagnostic; it never extrapolates a small trace into a 1B breakdown.
- `distributed/paper_scaling.py --transport nccl`: paired two-host results on
  local and large-halo graphs. Critical path is the per-sample maximum across
  ranks; exclusive host stages are not isolated device or wire times.

The exact commands and environment are in the downloadable reproduction artifact
linked from the docs and the sibling paper's `data/three-questions/REPRODUCE.md`.
The figure generator is `tiga-lang-paper/tools/build_three_questions.py`.
Exploratory failed comparisons, smoke runs and allocation audits are not pooled
into formal timing curves. No new run exceeds 1B edges; the original long sweep
is preserved without remeasurement.
